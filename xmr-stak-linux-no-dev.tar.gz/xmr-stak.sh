#!/bin/bash

# GPU config
export GPU_FORCE_64BIT_PTR=1
export GPU_MAX_HEAP_SIZE=100
export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100

SCRIPT_PATH=$(dirname $(readlink -f $0))

$SCRIPT_PATH/xmr-stak/ld-linux-x86-64.so.2 \
  --library-path $SCRIPT_PATH/xmr-stak \
  $SCRIPT_PATH/xmr-stak/xmr-stak \
  $*
